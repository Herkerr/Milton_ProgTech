﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace PT08_UnitTest
{
    public static class StringManipulation
    {
        // Reverse
        public static string ReverseString(string input)
        {
            char[] charArray = input.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }


        // Uppercase
        public static string ToUpperCase(string input)
        {
            return input.ToUpper();
        }


        // Count substring
        public static int CountOccurrences(string input, string substring)
        {
            int count = 0;
            int index = 0;
            while ((index = input.IndexOf(substring, index)) != -1)
            {
                index += substring.Length;
                count++;
            }
            return count;
        }


        // Truncate
        public static string TruncateString(string input, int maxLength)
        {
            if (input.Length <= maxLength)
            {
                return input;
            }
            else
            {
                return input.Substring(0, maxLength) + "...";
            }
        }


        // Remove Whitespace
        public static string RemoveWhiteSpaces(string input)
        {
            return Regex.Replace(input, @"\s+", "");
        }


        // Replace string
        public static string ReplaceSubstring(string input, string oldValue, string newValue)
        {
            return input.Replace(oldValue, newValue);
        }


        // PCI-DSS Example
        public static string MaskCreditCardNumber(string creditCardNumber)
        {
            // Use regular expression to remove non-numeric characters
            string digitsOnly = Regex.Replace(creditCardNumber, @"\D", "");

            // Get the last four digits
            string lastFourDigits = digitsOnly.Substring(digitsOnly.Length - 4);

            // Mask all but the last four digits
            string maskedDigits = new string('X', digitsOnly.Length - 4);

            // Combine masked digits with last four digits
            return maskedDigits + lastFourDigits;
        }


        // Base64 encoder
        public static string Base64Encode(string plainText)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedText)
        {
            byte[] base64EncodedBytes = Convert.FromBase64String(base64EncodedText);
            return Encoding.UTF8.GetString(base64EncodedBytes);
        }
    }
}



