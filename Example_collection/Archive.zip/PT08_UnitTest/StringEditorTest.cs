﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PT08_ConsoleApplications; // Számológép Namespace importálása

namespace UnitTestProject1
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using PT08_UnitTest;

    [TestClass]
    public class StringManipulationTests
    {
        // Reverse
        [TestMethod]
        public void ReverseString_ValidInput_ReturnsReversedString()
        {
            // Arrange
            string input = "hello";

            // Act
            string result = StringManipulation.ReverseString(input);

            // Assert
            Assert.AreEqual("olleh", result);
        }


        // Uppercase
        [TestMethod]
        public void ToUpperCase_ValidInput_ReturnsUpperCaseString()
        {
            // Arrange
            string input = "hello";

            // Act
            string result = StringManipulation.ToUpperCase(input);

            // Assert
            Assert.AreEqual("HELLO", result);
        }


        // Count substring
        [TestMethod]
        public void CountOccurrences_ValidInput_ReturnsCorrectCount()
        {
            // Arrange
            string input = "hello world, hello universe";
            string substring = "hello";

            // Act
            int count = StringManipulation.CountOccurrences(input, substring);

            // Assert
            Assert.AreEqual(2, count);
        }


        // Truncate
        [TestMethod]
        public void TruncateString_InputShorterThanMaxLength_ReturnsSameString()
        {
            // Arrange
            string input = "hello";
            int maxLength = 10;

            // Act
            string result = StringManipulation.TruncateString(input, maxLength);

            // Assert
            Assert.AreEqual(input, result);
        }
        [TestMethod]
        public void TruncateString_InputLongerThanMaxLength_ReturnsTruncatedStringWithEllipsis()
        {
            // Arrange
            string input = "this is a long string";
            int maxLength = 10;

            // Act
            string result = StringManipulation.TruncateString(input, maxLength);

            // Assert
            Assert.AreEqual("this is a ...", result);
        }
        [TestMethod]
        public void TruncateString_InputEqualToMaxLength_ReturnsSameString()
        {
            // Arrange
            string input = "exactly10";
            int maxLength = 10;

            // Act
            string result = StringManipulation.TruncateString(input, maxLength);

            // Assert
            Assert.AreEqual(input, result);
        }


        // Remove Whitespace
        [TestMethod]
        public void RemoveWhiteSpaces_NoWhiteSpaceInput_ReturnsSameString()
        {
            // Arrange
            string input = "hello";

            // Act
            string result = StringManipulation.RemoveWhiteSpaces(input);

            // Assert
            Assert.AreEqual(input, result);
        }
        [TestMethod]
        public void RemoveWhiteSpaces_InputWithWhiteSpace_ReturnsStringWithoutWhiteSpace()
        {
            // Arrange
            string input = "  hello \t world  \n";

            // Act
            string result = StringManipulation.RemoveWhiteSpaces(input);

            // Assert
            Assert.AreEqual("helloworld", result);
        }


        // Replace
        [TestMethod]
        public void ReplaceSubstring_SubstringPresentInInput_ReturnsStringWithSubstringReplaced()
        {
            // Arrange
            string input = "hello world";
            string oldValue = "world";
            string newValue = "universe";

            // Act
            string result = StringManipulation.ReplaceSubstring(input, oldValue, newValue);

            // Assert
            Assert.AreEqual("hello universe", result);
        }
        [TestMethod]
        public void ReplaceSubstring_SubstringNotPresentInInput_ReturnsOriginalString()
        {
            // Arrange
            string input = "hello world";
            string oldValue = "planet";
            string newValue = "universe";

            // Act
            string result = StringManipulation.ReplaceSubstring(input, oldValue, newValue);

            // Assert
            Assert.AreEqual(input, result);
        }

        // PCI-DSS Compliance example
        [TestMethod]
        public void MaskCreditCardNumber_ValidInput_ReturnsMaskedCreditCardNumber()
        {
            // Arrange
            string creditCardNumber = "1111-2222-3333-4454";

            // Act
            string result = StringManipulation.MaskCreditCardNumber(creditCardNumber);

            // Assert
            Assert.AreEqual("XXXXXXXXXXXX4454", result);
        }


        // Base64 Encoder
        [TestMethod]
        public void Base64Encode_ValidInput_ReturnsEncodedString()
        {
            // Arrange
            string plainText = "Hello, world!";

            // Act
            string encodedString = StringManipulation.Base64Encode(plainText);

            // Assert
            Assert.AreEqual("SGVsbG8sIHdvcmxkIQ==", encodedString);
        }

        [TestMethod]
        public void Base64Decode_ValidInput_ReturnsDecodedString()
        {
            // Arrange
            string base64EncodedString = "SGVsbG8sIHdvcmxkIQ==";

            // Act
            string decodedString = StringManipulation.Base64Decode(base64EncodedString);

            // Assert
            Assert.AreEqual("Hello, world!", decodedString);
        }
    }
}