﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PT08_ConsoleApplications; // Számológép Namespace importálása

namespace UnitTestProject1
{
    [TestClass]
    public class SzamoloGepUnitTest
    {
        [TestMethod]
        public void OsszeadTest()
        {
            // Arrange - Összeállítjuk a megfelelő inputokat és predikciókat
            SzamoloGep target = new SzamoloGep();           // Példányosítunk
            int a = 2;                                      // Input A
            int b = 2;                                      // Input B
            int expected = 4;                               // Várt eredmény

            // DEBUG - Kapott inputok naplózása
            Debug.WriteLine($"Input A: {a}, Input B: {b}");

            try
            {
                // Act - Metódushívás elvégzése
                int actual = target.Osszead(a, b);          // Metódushívás

                // DEBUG - Kapott eredmény naplózása
                Debug.WriteLine($"Eredmény: {actual}");

                // Assert - Eredményeink ellenőrzése
                Assert.AreEqual(expected, actual);          // Ellenőrzés

                // DEBUG - Összehasonlítás, avagy Test eredmény naplózása
                Debug.WriteLine("PASS");
            }
            catch (AssertFailedException ex)
            {
                // DEBUG - Hibás eredmény esetén naplózás
                Debug.WriteLine($"FAIL: {ex.Message}");
                throw; // Jelezzük, ha a teszt sikertelen
            }
            catch (Exception ex)
            {
                // DEBUG - Egyéb hibák esetén naplózás
                Debug.WriteLine($"ERROR: {ex.Message}");
            }
        }
        [TestMethod]
        public void KivonTest()
        {
            // Arrange
            SzamoloGep target = new SzamoloGep();
            int a = 2;
            int b = 2;
            int expected = 0;
            Debug.WriteLine($"Input A: {a}, Input B: {b}");

            try
            {
                // Act
                int actual = target.Kivon(a, b);
                Debug.WriteLine($"Eredmény: {actual}");

                // Assert
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR: {ex.Message}");
            }
        }
        [TestMethod]
        public void OsztasTest()
        {
            // Arrange
            SzamoloGep target = new SzamoloGep();
            int a = 2;
            int b = 2;
            int expected = 1;
            Debug.WriteLine($"Input A: {a}, Input B: {b}");

            try
            {
                // Act
                int actual = target.Oszt(a, b);
                Debug.WriteLine($"Eredmény: {actual}");

                // Assert
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR: {ex.Message}");
            }
        }
        [TestMethod]
        public void SzorozTest()
        {
            // Arrange
            SzamoloGep target = new SzamoloGep();
            int a = 2;
            int b = 2;
            int expected = 4;
            Debug.WriteLine($"Input A: {a}, Input B: {b}");

            try
            {
                // Act
                int actual = target.Szoroz(a, b);
                Debug.WriteLine($"Eredmény: {actual}");

                // Assert
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR: {ex.Message}");
            }
        }
        [TestMethod]
        public void HatvanyozTest()
        {
            // Arrange
            SzamoloGep target = new SzamoloGep();
            int a = 2;
            int b = 2;
            int expected = 4;
            Debug.WriteLine($"Input A: {a}, Input B: {b}");

            try
            {
                // Act
                int actual = target.Hatvanyoz(a, b);
                Debug.WriteLine($"Eredmény: {actual}");

                // Assert
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR: {ex.Message}");
            }
        }
    }
}