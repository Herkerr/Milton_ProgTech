﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PT08_ConsoleApplications; // Számológép Namespace importálása

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod2()
        {;

            // Arrange - Összeállítjuk a megfelelő inputokat és predikciókat
            SzamoloGep target = new SzamoloGep();   // Példányosítunk
            int a = 2;                              // Input A
            int b = 2;                              // Input B
            int expected = 0;                       // Várt eredmény

            // DEBUG - Kapott inputok naplózása
            Debug.WriteLine($"SzamoloGep Kivonás Unit Test Input A: {a}, Input B: {b}");

            try
            {
                // Act - Metódushívás elvégzése
                int actual = target.Kivon(a, b);      // Metódushívás

                // DEBUG - Kapott eredmény naplózása
                Debug.WriteLine($"SzamoloGep Kivonás Unit Test Result: {actual}");

                // Assert - Eredményeink ellenőrzése
                Assert.AreEqual(expected, actual);      // Ellenőrzés

                // DEBUG - Összehasonlítás, avagy Test eredmény naplózása
                Debug.WriteLine("SzamoloGep Kivonás Unit Test: PASS");
            }
            catch (AssertFailedException ex)
            {
                // DEBUG - Hibás eredmény esetén naplózás
                Debug.WriteLine($"SzamoloGep Kivonás Unit Test FAIL: {ex.Message}");
                throw; // Jelezzük, ha a teszt sikertelen
            }
            catch (Exception ex)
            {
                // DEBUG - Egyéb hibák esetén naplózás
                Debug.WriteLine($"SzamoloGep Kivonás Unit Test ERROR: {ex.Message}");
            }
        }
    }
}