﻿namespace PT08_ConsoleApplications
{
    public class MegajanlottCheck
    {
        public int PontszamSum(int feladatokPontjai, int tesztPontjai)
        {
            return feladatokPontjai + tesztPontjai;
        }

        public decimal Szazalek(int feladatokPontjai, int tesztPontjai)
        {
            int osszpont = feladatokPontjai + tesztPontjai;
            int elerheto = MaxPont();
            decimal szazalekPont = ((decimal)osszpont / elerheto) * 100;
            return szazalekPont;
        }
        // Private Method-ok
        private int MaxPont()
        {
            return 60;
        }

        private int NegyesPonthatar()
        {
            return 42;
        }

        private int OtosPonthatar()
        {
            return 48;
        }
    }
}