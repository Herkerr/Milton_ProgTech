﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PT08_ConsoleApplications;

namespace UnitTestProject1
{
    [TestClass]
    public class MegajanlottUnitTest
    {
        [TestMethod]
        public void PontszamSumTest()
        {;
            MegajanlottCheck target = new MegajanlottCheck();
            int feladatokPontjai = 30;
            int tesztPontjai = 30;
            int expected = 60;
            Debug.WriteLine($"MegajanlottCheck Unit Test Input A: {feladatokPontjai}, Input B: {tesztPontjai}");

            try
            {
                int actual = target.PontszamSum(feladatokPontjai, tesztPontjai);
                Debug.WriteLine($"MegajanlottCheck Unit Test Result: {actual}");
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("MegajanlottCheck Unit Test: PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"MegajanlottCheck Unit Test FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"MegajanlottCheck Unit Test ERROR: {ex.Message}");
            }
        }
        [TestMethod]
        public void SzazalekTest()
        {
            ;

            MegajanlottCheck target = new MegajanlottCheck();
            int feladatokPontjai = 18;
            int tesztPontjai = 30;
            int expected = 80;
            Debug.WriteLine($"MegajanlottCheck Unit Test Input A: {feladatokPontjai}, Input B: {tesztPontjai}");

            try
            {
                decimal actual = target.Szazalek(feladatokPontjai, tesztPontjai);
                Debug.WriteLine($"MegajanlottCheck Unit Test Result: {actual}");
                Assert.AreEqual(expected, actual);
                Debug.WriteLine("MegajanlottCheck Unit Test: PASS");
            }
            catch (AssertFailedException ex)
            {
                Debug.WriteLine($"MegajanlottCheck Unit Test FAIL: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"MegajanlottCheck Unit Test ERROR: {ex.Message}");
            }
        }
    }
}