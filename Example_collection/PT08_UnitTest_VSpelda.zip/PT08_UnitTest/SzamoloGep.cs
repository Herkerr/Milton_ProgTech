﻿namespace PT08_ConsoleApplications
{
    public class SzamoloGep
    {
        public int Osszead(int a, int b)
        {
            return a + b;
        }
        public int Kivon(int a, int b)
        {
            return a - b;
        }
        public int Oszt(int a, int b)
        {
            return a / b;
        }
        public int Szoroz(int a, int b)
        {
            return a * b;
        }
        public int Hatvanyoz(int a, int b)
        {
            return (int)Math.Pow(a, b);
        }
    }
}